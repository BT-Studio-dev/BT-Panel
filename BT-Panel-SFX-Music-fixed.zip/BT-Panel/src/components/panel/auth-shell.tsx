import { useLayoutEffect, useState, type ReactNode } from "react";
import { getPublicAppearance } from "@/lib/panel/server";
import { applyTheme } from "@/lib/panel/theme";
import { DEFAULT_GENERAL, DEFAULT_THEME, type PublicAppearance } from "@/lib/panel/types";
import { WallpaperLayer } from "./wallpaper-layer";
import { BrandMark } from "./brand-mark";

export function AuthShell({
  title,
  children,
  footer,
}: {
  title: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const [appearance, setAppearance] = useState<PublicAppearance>({
    theme: DEFAULT_THEME,
    general: DEFAULT_GENERAL,
  });

  useLayoutEffect(() => {
    applyTheme(DEFAULT_THEME);
    let cancelled = false;
    void getPublicAppearance()
      .then((data) => {
        if (cancelled) return;
        setAppearance(data);
        applyTheme(data.theme);
      })
      .catch(() => {
        applyTheme(DEFAULT_THEME);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="relative min-h-dvh">
      <WallpaperLayer theme={appearance.theme} />
      <main className="relative z-10 flex min-h-dvh items-center justify-center px-4 py-10">
        <div className="glass w-full max-w-[360px] px-8 py-8 text-center">
          <div className="mb-5 flex flex-col items-center gap-3">
            <BrandMark className="size-11" />
            <div>
              <h1 className="text-[22px] font-extrabold tracking-tight text-ice">
                {appearance.general.panelName || "BT Panel"}
              </h1>
              <p className="mt-1 text-[13px] font-semibold text-steel">{title}</p>
            </div>
          </div>
          {children}
          {footer ? <div className="mt-5 text-[12.5px] font-bold text-ice">{footer}</div> : null}
        </div>
      </main>
    </div>
  );
}
