export function BrandMark({ className = "size-8" }: { className?: string }) {
  return <img src="/brand-mark.svg" alt="" className={className} />;
}
