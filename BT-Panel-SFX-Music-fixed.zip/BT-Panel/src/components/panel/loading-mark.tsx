export function LoadingMark({ className = "size-16" }: { className?: string }) {
  return <img src="/loading.svg" alt="" className={className} />;
}
