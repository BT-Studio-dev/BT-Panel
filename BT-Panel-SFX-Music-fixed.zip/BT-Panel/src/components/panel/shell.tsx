import { useEffect } from "react";
import { hydrateSidebar, usePanelUi } from "@/lib/panel/store";
import { LoadingMark } from "./loading-mark";
import { Header } from "./header";
import { MusicPlayer } from "./music-player";
import { Sidebar } from "./sidebar";
import { SoundEffects } from "./sound-effects";
import { WallpaperLayer } from "./wallpaper-layer";
import { usePanel } from "./context";
import { AccountView } from "./views/account-view";
import { HomeView } from "./views/home-view";
import { MusicPanel, SettingsView } from "./views/settings-view";
import { TeamView } from "./views/team-view";
import { UsersView } from "./views/users-view";

export function PanelShell() {
  const { loading, error, profile, draft, settings } = usePanel();
  const view = usePanelUi((s) => s.view);

  useEffect(() => {
    hydrateSidebar();
  }, []);

  useEffect(() => {
    document.title = settings.panelName || "BT Panel";
  }, [settings.panelName]);

  if (loading) {
    return (
      <div className="relative min-h-dvh">
        <WallpaperLayer theme={draft} />
        <div className="relative z-10 grid min-h-dvh place-items-center">
          <div className="glass flex flex-col items-center gap-4 px-10 py-8 text-center">
            <LoadingMark className="size-16" />
            <div>
              <div className="text-[15px] font-extrabold">Loading panel…</div>
              <div className="mt-1 text-[12px] font-semibold text-steel">Restoring session and workspace</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="relative min-h-dvh">
        <WallpaperLayer theme={draft} />
        <div className="relative z-10 grid min-h-dvh place-items-center px-4">
          <div className="glass max-w-md px-8 py-6 text-center">
            <div className="text-[16px] font-extrabold">Could not open the panel</div>
            <p className="mt-2 text-[13px] font-semibold text-steel">{error || "Sign in again to continue."}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-dvh">
      <WallpaperLayer theme={draft} />
      <div className="relative z-10 flex min-h-dvh">
        <Sidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <Header />
          <main className="scrollbar-thin min-h-0 flex-1 overflow-y-auto px-4 pb-8 md:px-6">
            {view === "home" ? <HomeView /> : null}
            {view === "team" ? <TeamView /> : null}
            {view === "music" ? <MusicPanel /> : null}
            {view === "settings" ? <SettingsView /> : null}
            {view === "users" ? <UsersView /> : null}
            {view === "account" ? <AccountView /> : null}
          </main>
        </div>
      </div>
      <MusicPlayer />
      <SoundEffects />
    </div>
  );
}
