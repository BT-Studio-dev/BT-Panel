import { useMemo, useState } from "react";
import { toast } from "sonner";
import { addMedia, addMusicTrack, deleteMedia, deleteMusicTrack } from "@/lib/panel/server";
import { usePanelUi } from "@/lib/panel/store";
import { DEFAULT_THEME, type SettingsTab } from "@/lib/panel/types";
import { WALLPAPER_CATEGORIES, WALLPAPER_LIBRARY, type WallpaperCategory } from "@/lib/panel/wallpapers";
import { applyTheme } from "@/lib/panel/theme";
import { compressImageFile } from "@/lib/utils";
import { playSfx, setSfxEnabled, setSfxVolume, useSfxSettings } from "@/lib/panel/sfx";
import { usePanel } from "../context";

const TABS: { id: SettingsTab; label: string }[] = [
  { id: "general", label: "General" },
  { id: "appearance", label: "Appearance" },
  { id: "wallpapers", label: "4K Wallpapers" },
  { id: "music", label: "Music" },
  { id: "bars", label: "Bars" },
];

export function SettingsView() {
  const { settingsTab, setSettingsTab } = usePanelUi();
  return (
    <div>
      <div className="mb-4">
        <h2 className="text-[22px] font-extrabold tracking-tight">Settings Management</h2>
        <p className="mt-1 text-[13px] font-semibold text-steel">
          Configure your panel, appearance, integrations, and runtime defaults.
        </p>
      </div>
      <div className="mb-4 flex flex-wrap gap-1.5">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            className={[
              "min-h-11 rounded-full px-4 text-[13px] font-extrabold",
              settingsTab === tab.id ? "bg-[var(--accent)] text-white" : "bg-white/6 text-steel",
            ].join(" ")}
            onClick={() => setSettingsTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      {settingsTab === "general" ? <GeneralPanel /> : null}
      {settingsTab === "appearance" ? <AppearancePanel /> : null}
      {settingsTab === "wallpapers" ? <WallpaperPanel /> : null}
      {settingsTab === "music" ? <MusicPanel /> : null}
      {settingsTab === "bars" ? <BarsPanel /> : null}
    </div>
  );
}

function GeneralPanel() {
  const { settings, persistGeneral } = usePanel();
  const [form, setForm] = useState({
    panelName: settings.panelName,
    panelSubtitle: settings.panelSubtitle,
    welcomeTitle: settings.welcomeTitle,
    welcomeMessage: settings.welcomeMessage,
  });
  const [busy, setBusy] = useState(false);

  return (
    <div className="glass p-5">
      <h3 className="text-[16px] font-extrabold">Panel identity</h3>
      <p className="mt-1 text-[13px] font-semibold text-steel">Name, browser title, and the Home welcome copy.</p>
      <div className="mt-5 grid gap-4 md:grid-cols-2">
        <Field label="Panel name">
          <input className="panel-input" value={form.panelName} onChange={(e) => setForm({ ...form, panelName: e.target.value })} />
        </Field>
        <Field label="Subtitle">
          <input className="panel-input" value={form.panelSubtitle} onChange={(e) => setForm({ ...form, panelSubtitle: e.target.value })} />
        </Field>
        <Field label="Welcome heading">
          <input className="panel-input" value={form.welcomeTitle} onChange={(e) => setForm({ ...form, welcomeTitle: e.target.value })} />
        </Field>
        <Field label="Welcome message" className="md:col-span-2">
          <textarea
            className="panel-input min-h-[88px] resize-y"
            value={form.welcomeMessage}
            onChange={(e) => setForm({ ...form, welcomeMessage: e.target.value })}
          />
        </Field>
      </div>
      <div className="mt-5 rounded-[14px] border border-dashed border-white/15 p-4">
        <div className="text-[11px] font-extrabold tracking-[0.12em] text-steel uppercase">Live preview</div>
        <div className="mt-2 text-[18px] font-extrabold">{form.welcomeTitle}</div>
        <p className="mt-1 text-[13px] font-semibold text-steel">{form.welcomeMessage}</p>
      </div>
      <button
        type="button"
        className="btn-accent mt-5"
        disabled={busy}
        onClick={() => {
          setBusy(true);
          void persistGeneral(form).finally(() => setBusy(false));
        }}
      >
        {busy ? "Saving…" : "Save General"}
      </button>
    </div>
  );
}

function AppearancePanel() {
  const { draft, setDraft, persistTheme, media, setMedia } = usePanel();
  const [url, setUrl] = useState("");
  const [saving, setSaving] = useState(false);

  async function onUpload(file?: File) {
    if (!file) return;
    try {
      const isVideo = file.type.startsWith("video/");
      if (isVideo) {
        toast.error("Video backgrounds need a direct HTTPS URL in this hosted panel.");
        return;
      }
      const dataUrl = await compressImageFile(file, 1600, 0.8);
      const next = await addMedia({ data: { name: file.name, url: dataUrl, kind: "image" } });
      setMedia(next);
      setDraft({ wallpaperUrl: dataUrl });
      toast.success("Background uploaded");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    }
  }

  return (
    <div className="glass p-5">
      <h3 className="text-[16px] font-extrabold">Panel Appearance & Glassmorphism</h3>
      <p className="mt-1 text-[13px] font-semibold text-steel">
        Customize background, glassmorphism blur, transparency, and panel colors.
      </p>
      <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,0.95fr)_minmax(280px,1.05fr)]">
        <div>
          <div className="text-[13px] font-extrabold">Background Media</div>
          <label
            className="mt-3 flex min-h-[120px] cursor-pointer flex-col items-center justify-center rounded-[14px] border border-dashed border-white/20 bg-black/20 text-center"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              void onUpload(e.dataTransfer.files[0]);
            }}
          >
            <span className="text-[14px] font-extrabold">Click or drag to upload</span>
            <span className="mt-1 text-[12px] font-semibold text-steel">PNG or JPEG, compressed for the panel</span>
            <input type="file" accept="image/*" className="hidden" onChange={(e) => void onUpload(e.target.files?.[0])} />
          </label>
          {media.length > 0 ? (
            <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-4">
              {media.map((file) => (
                <div key={file.id} className="relative">
                  <button type="button" className="wallpaper-tile w-full" onClick={() => setDraft({ wallpaperUrl: file.url })}>
                    {file.kind === "image" ? <img src={file.url} alt="" /> : <div className="grid size-full place-items-center text-[11px]">Video</div>}
                  </button>
                  <button
                    type="button"
                    className="absolute top-1 right-1 rounded-full bg-black/70 px-2 py-0.5 text-[10px] font-bold"
                    onClick={() => {
                      void deleteMedia({ data: { id: file.id } })
                        .then(setMedia)
                        .catch((err) => toast.error(err instanceof Error ? err.message : "Failed"));
                    }}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          ) : null}
          <div className="mt-4">
            <div className="text-[12px] font-bold text-steel">External Image / Video URL</div>
            <div className="mt-1.5 flex flex-col gap-2 sm:flex-row">
              <input className="panel-input" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://images.unsplash.com/..." />
              <button
                type="button"
                className="btn-accent shrink-0"
                onClick={() => {
                  if (!url.trim()) return;
                  setDraft({ wallpaperUrl: url.trim() });
                  toast.success("Background URL applied");
                }}
              >
                Apply URL
              </button>
            </div>
          </div>
          <label className="mt-5 flex items-center justify-between gap-3 rounded-[12px] border border-white/10 px-3 py-3">
            <span className="text-[13px] font-bold">Show Team</span>
            <input
              type="checkbox"
              checked={draft.showTeam}
              onChange={(e) => setDraft({ showTeam: e.target.checked })}
            />
          </label>
        </div>
        <div className="grid gap-4">
          <Slider label="Background Blur" value={draft.bgBlur} max={100} suffix="px" onChange={(v) => setDraft({ bgBlur: v })} />
          <Slider label="Background Opacity" value={draft.bgOpacity} max={100} suffix="%" onChange={(v) => setDraft({ bgOpacity: v })} />
          <Color label="Accent Color" value={draft.accentColor} onChange={(v) => setDraft({ accentColor: v })} />
          <Color label="Glass Tint" value={draft.glassTint} hint="Base color for glassmorphism panels" onChange={(v) => setDraft({ glassTint: v })} />
          <Slider label="Glass Opacity" value={draft.glassOpacity} max={100} suffix="%" hint="0% = fully transparent, 100% = full tint" onChange={(v) => setDraft({ glassOpacity: v })} />
          <Color label="Nav Text" value={draft.navText} hint="Sidebar inactive item text" onChange={(v) => setDraft({ navText: v })} />
          <Color label="Nav Text Active" value={draft.navTextActive} hint="Sidebar active item text" onChange={(v) => setDraft({ navTextActive: v })} />
          <Slider label="Glass Blur" value={draft.glassBlur} max={40} suffix="px" onChange={(v) => setDraft({ glassBlur: v })} />
          <Slider label="Border Radius" value={draft.borderRadius} max={24} suffix="px" onChange={(v) => setDraft({ borderRadius: v })} />
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              className="btn-accent"
              disabled={saving}
              onClick={() => {
                setSaving(true);
                void persistTheme().finally(() => setSaving(false));
              }}
            >
              {saving ? "Saving…" : "Save Theme"}
            </button>
            <button
              type="button"
              className="btn-ghost"
              onClick={() => {
                setDraft(DEFAULT_THEME);
                applyTheme(DEFAULT_THEME);
              }}
            >
              Reset to Default
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function WallpaperPanel() {
  const { setDraft } = usePanel();
  const [category, setCategory] = useState<WallpaperCategory>("all");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 8;
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return WALLPAPER_LIBRARY.filter((item) => {
      if (category !== "all" && item.category !== category) return false;
      if (q && !item.title.toLowerCase().includes(q) && !item.category.includes(q)) return false;
      return true;
    });
  }, [category, query]);
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const slice = filtered.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div className="glass p-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h3 className="text-[16px] font-extrabold">4K Wallpapers Library</h3>
          <p className="mt-1 text-[13px] font-semibold text-steel">Browse, preview, and apply cinematic backgrounds.</p>
        </div>
      </div>
      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <input
          className="panel-input"
          placeholder="Search wallpapers..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setPage(1);
          }}
        />
      </div>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {WALLPAPER_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            type="button"
            className={[
              "min-h-10 rounded-full px-3 text-[12px] font-extrabold",
              category === cat.id ? "bg-[var(--accent)] text-white" : "bg-white/6 text-steel",
            ].join(" ")}
            onClick={() => {
              setCategory(cat.id);
              setPage(1);
            }}
          >
            {cat.label}
          </button>
        ))}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        {slice.map((item) => (
          <button
            key={item.id}
            type="button"
            className="wallpaper-tile"
            onClick={() => {
              setDraft({ wallpaperUrl: item.full });
              toast.success(`Applied ${item.title}`);
            }}
          >
            <img src={item.thumb} alt="" />
            <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent px-2 py-2 text-left text-[12px] font-extrabold">
              {item.title}
            </span>
          </button>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-between">
        <button type="button" className="btn-ghost" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
          Previous
        </button>
        <span className="text-[12px] font-bold text-steel">
          Page {page} of {pages}
        </span>
        <button type="button" className="btn-ghost" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>
          Next
        </button>
      </div>
    </div>
  );
}

export function MusicPanel() {
  const { settings, tracks, setTracks, setSettings, persistMusic } = usePanel();
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const sfx = useSfxSettings();

  return (
    <div className="glass p-5">
      <h3 className="text-[16px] font-extrabold">Music studio</h3>
      <p className="mt-1 text-[13px] font-semibold text-steel">
        Ambient music and subtle interface feedback for buttons, navigation, and alerts.
      </p>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <Toggle label="Enabled" checked={settings.enabled} onChange={(enabled) => void persistMusic({ enabled })} />
        <Toggle label="Autoplay" checked={settings.autoplay} onChange={(autoplay) => void persistMusic({ autoplay })} />
        <Toggle label="Loop" checked={settings.loop} onChange={(loop) => void persistMusic({ loop })} />
        <Slider
          label="Volume"
          value={Math.round(settings.volume * 100)}
          max={100}
          suffix="%"
          onChange={(v) => setSettings({ ...settings, volume: v / 100 })}
          onCommit={(v) => void persistMusic({ volume: v / 100 })}
        />
      </div>
      <div className="mt-5 border-t border-white/10 pt-5">
        <div className="mb-3">
          <div className="text-[14px] font-extrabold">Interface sound effects</div>
          <div className="mt-1 text-[12px] font-semibold text-steel">Stored locally for each browser.</div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Toggle label="SFX enabled" checked={sfx.enabled} onChange={setSfxEnabled} />
          <Slider
            label="SFX volume"
            value={Math.round(sfx.volume * 100)}
            max={100}
            suffix="%"
            onChange={(value) => setSfxVolume(value / 100)}
          />
        </div>
        <button
          type="button"
          className="btn-ghost mt-3"
          data-sfx-ignore="true"
          onClick={() => playSfx("success", true)}
        >
          Test SFX
        </button>
      </div>
      <div className="mt-5 grid gap-2 md:grid-cols-[1fr_1.4fr_auto]">
        <input className="panel-input" placeholder="Track name" value={name} onChange={(e) => setName(e.target.value)} />
        <input className="panel-input" placeholder="https://example.com/track.mp3" value={url} onChange={(e) => setUrl(e.target.value)} />
        <button
          type="button"
          className="btn-accent"
          disabled={busy}
          onClick={() => {
            setBusy(true);
            void addMusicTrack({ data: { name, url } })
              .then((result) => {
                setTracks(result.tracks);
                setSettings(result.settings);
                setName("");
                setUrl("");
                toast.success("Track added");
              })
              .catch((err) => toast.error(err instanceof Error ? err.message : "Failed"))
              .finally(() => setBusy(false));
          }}
        >
          Add URL
        </button>
      </div>
      <div className="mt-4 grid gap-2">
        {tracks.length === 0 ? (
          <p className="py-6 text-center text-[13px] font-semibold text-steel">No tracks yet. Add an MP3, WAV, or OGG URL.</p>
        ) : (
          tracks.map((track) => (
            <div key={track.id} className="flex flex-col gap-2 rounded-[12px] border border-white/10 px-3 py-3 sm:flex-row sm:items-center">
              <button
                type="button"
                className="min-w-0 flex-1 text-left"
                onClick={() => void persistMusic({ selectedTrackId: track.id, enabled: true })}
              >
                <div className="truncate text-[13px] font-extrabold">{track.name}</div>
                <div className="truncate text-[11px] font-semibold text-steel">
                  {track.source === "bundled" ? "Included ambient track" : track.url}
                </div>
              </button>
              <div className="flex gap-2">
                {settings.selectedTrackId === track.id ? (
                  <span className="grid min-h-10 place-items-center rounded-full bg-[var(--accent)] px-3 text-[11px] font-extrabold text-white">
                    Selected
                  </span>
                ) : (
                  <button type="button" className="btn-ghost min-h-10 text-[12px]" onClick={() => void persistMusic({ selectedTrackId: track.id })}>
                    Select
                  </button>
                )}
                {track.source !== "bundled" ? <button
                  type="button"
                  className="btn-danger"
                  onClick={() => {
                    void deleteMusicTrack({ data: { id: track.id } })
                      .then((result) => {
                        setTracks(result.tracks);
                        setSettings(result.settings);
                      })
                      .catch((err) => toast.error(err instanceof Error ? err.message : "Failed"));
                  }}
                >
                  Delete
                </button> : null}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function BarsPanel() {
  const { settings, persistBars } = usePanel();
  const [form, setForm] = useState({
    showAdminStats: settings.showAdminStats,
    showVersion: settings.showVersion,
    showRole: settings.showRole,
    showHeaderUser: settings.showHeaderUser,
  });

  return (
    <div className="glass p-5">
      <h3 className="text-[16px] font-extrabold">Home indicators</h3>
      <p className="mt-1 text-[13px] font-semibold text-steel">Choose which Home dashboard indicators are shown.</p>
      <div className="mt-5 grid gap-2">
        <Toggle label="Admin statistics" checked={form.showAdminStats} onChange={(showAdminStats) => setForm({ ...form, showAdminStats })} />
        <Toggle label="Panel version card" checked={form.showVersion} onChange={(showVersion) => setForm({ ...form, showVersion })} />
        <Toggle label="Signed-in role phrase" checked={form.showRole} onChange={(showRole) => setForm({ ...form, showRole })} />
        <Toggle label="Top-header account control" checked={form.showHeaderUser} onChange={(showHeaderUser) => setForm({ ...form, showHeaderUser })} />
      </div>
      <button type="button" className="btn-accent mt-5" onClick={() => void persistBars(form)}>
        Save Bars
      </button>
    </div>
  );
}

function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={["block text-[12px] font-bold text-steel", className].filter(Boolean).join(" ")}>
      {label}
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

function Slider({
  label,
  value,
  max,
  suffix,
  hint,
  onChange,
  onCommit,
}: {
  label: string;
  value: number;
  max: number;
  suffix: string;
  hint?: string;
  onChange: (value: number) => void;
  onCommit?: (value: number) => void;
}) {
  return (
    <label className="block">
      <div className="flex items-center justify-between text-[12px] font-bold text-steel">
        <span>{label}</span>
        <span className="font-mono text-ice">
          {value}
          {suffix}
        </span>
      </div>
      <input
        type="range"
        className="range-input mt-2"
        min={0}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        onMouseUp={onCommit ? (e) => onCommit(Number((e.target as HTMLInputElement).value)) : undefined}
        onTouchEnd={onCommit ? (e) => onCommit(Number((e.target as HTMLInputElement).value)) : undefined}
      />
      {hint ? <div className="mt-1 text-[11px] font-semibold text-white/40">{hint}</div> : null}
    </label>
  );
}

function Color({
  label,
  value,
  hint,
  onChange,
}: {
  label: string;
  value: string;
  hint?: string;
  onChange: (value: string) => void;
}) {
  const safe = /^#[0-9a-fA-F]{6}$/.test(value || "") ? value : "#0a0c14";
  return (
    <label className="flex items-center justify-between gap-3">
      <div>
        <div className="text-[12px] font-bold text-steel">{label}</div>
        {hint ? <div className="text-[11px] font-semibold text-white/40">{hint}</div> : null}
      </div>
      <input
        type="color"
        value={safe}
        onChange={(e) => onChange(e.target.value)}
        className="h-10 w-14 cursor-pointer rounded-md border border-white/10 bg-transparent"
      />
    </label>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (value: boolean) => void }) {
  return (
    <label className="flex min-h-12 items-center justify-between gap-3 rounded-[12px] border border-white/10 px-3">
      <span className="text-[13px] font-bold">{label}</span>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
    </label>
  );
}
