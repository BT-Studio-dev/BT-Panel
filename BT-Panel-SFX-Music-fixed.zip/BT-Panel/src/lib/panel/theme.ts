import { hexToRgb, toHexColor } from "@/lib/utils";
import { DEFAULT_THEME, type ThemeSettings } from "./types";

export function applyTheme(theme: ThemeSettings) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const wallpaper = theme.wallpaperUrl
    ? `url("${theme.wallpaperUrl.replace(/"/g, '\\"')}")`
    : "none";
  const tint = toHexColor(theme.glassTint, DEFAULT_THEME.glassTint);
  const accent = toHexColor(theme.accentColor, DEFAULT_THEME.accentColor);
  root.style.setProperty("--wallpaper-url", wallpaper);
  root.style.setProperty("--bg-blur", `${theme.bgBlur || 0}px`);
  root.style.setProperty("--bg-opacity", String((Number.isFinite(theme.bgOpacity) ? theme.bgOpacity : 100) / 100));
  root.style.setProperty("--accent", accent);
  root.style.setProperty("--accent-glow", `color-mix(in srgb, ${accent} 34%, transparent)`);
  root.style.setProperty("--glass-tint", hexToRgb(tint));
  root.style.setProperty("--nav-text", toHexColor(theme.navText, DEFAULT_THEME.navText));
  root.style.setProperty("--nav-text-active", toHexColor(theme.navTextActive, DEFAULT_THEME.navTextActive));
  root.style.setProperty("--glass-blur", `${theme.glassBlur || 0}px`);
  root.style.setProperty("--glass-saturate", `${theme.glassSaturate || 160}%`);
  root.style.setProperty("--panel-radius", `${theme.borderRadius || 16}px`);
  const opacity = Number.isFinite(theme.glassOpacity) ? theme.glassOpacity : DEFAULT_THEME.glassOpacity;
  root.style.setProperty("--glass-opacity", String(Math.min(100, Math.max(0, opacity)) / 100));
}