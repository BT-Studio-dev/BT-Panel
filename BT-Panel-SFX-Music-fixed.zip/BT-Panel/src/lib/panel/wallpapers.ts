export type WallpaperCategory =
  | "all"
  | "dark"
  | "space"
  | "nature"
  | "city"
  | "cars"
  | "abstract"
  | "minimal"
  | "tech"
  | "fantasy";

export type WallpaperItem = {
  id: string;
  title: string;
  category: Exclude<WallpaperCategory, "all">;
  thumb: string;
  full: string;
};

const u = (id: string, w = 1920) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=80`;

export const WALLPAPER_CATEGORIES: { id: WallpaperCategory; label: string }[] = [
  { id: "all", label: "All" },
  { id: "dark", label: "Dark" },
  { id: "space", label: "Space" },
  { id: "nature", label: "Nature" },
  { id: "city", label: "City" },
  { id: "cars", label: "Cars" },
  { id: "abstract", label: "Abstract" },
  { id: "minimal", label: "Minimal" },
  { id: "tech", label: "Tech" },
  { id: "fantasy", label: "Fantasy" },
];

export const WALLPAPER_LIBRARY: WallpaperItem[] = [
  {
    id: "firewatch",
    title: "Lookout",
    category: "nature",
    thumb: "/wallpapers/firewatch.png",
    full: "/wallpapers/firewatch.png",
  },
  {
    id: "harbor",
    title: "Neon Harbor",
    category: "city",
    thumb: "/wallpapers/city-night.jpg",
    full: "/wallpapers/city-night.jpg",
  },
  {
    id: "tokyo-night",
    title: "Rain District",
    category: "city",
    thumb: u("photo-1540959733332-eab4deabeeaf", 640),
    full: u("photo-1540959733332-eab4deabeeaf"),
  },
  {
    id: "nyc",
    title: "Night Grid",
    category: "city",
    thumb: u("photo-1480714378408-67cf0d13bc1b", 640),
    full: u("photo-1480714378408-67cf0d13bc1b"),
  },
  {
    id: "hongkong",
    title: "Harbor Lights",
    category: "city",
    thumb: u("photo-1508804185872-d7badad00f7d", 640),
    full: u("photo-1508804185872-d7badad00f7d"),
  },
  {
    id: "space-1",
    title: "Deep Field",
    category: "space",
    thumb: u("photo-1462331940025-496dfbfc7824", 640),
    full: u("photo-1462331940025-496dfbfc7824"),
  },
  {
    id: "space-2",
    title: "Milky Veil",
    category: "space",
    thumb: u("photo-1419242902214-272b3f66ee7a", 640),
    full: u("photo-1419242902214-272b3f66ee7a"),
  },
  {
    id: "earth-night",
    title: "Orbital Night",
    category: "space",
    thumb: u("photo-1446776811953-b23d57bd21aa", 640),
    full: u("photo-1446776811953-b23d57bd21aa"),
  },
  {
    id: "alps",
    title: "High Pass",
    category: "nature",
    thumb: u("photo-1506905925346-21bda4d32df4", 640),
    full: u("photo-1506905925346-21bda4d32df4"),
  },
  {
    id: "forest",
    title: "Fog Timber",
    category: "nature",
    thumb: u("photo-1441974231531-c6227db76b6e", 640),
    full: u("photo-1441974231531-c6227db76b6e"),
  },
  {
    id: "coast",
    title: "Black Sand",
    category: "nature",
    thumb: u("photo-1507525428034-b723cf961d3e", 640),
    full: u("photo-1507525428034-b723cf961d3e"),
  },
  {
    id: "dark-1",
    title: "Obsidian Peak",
    category: "dark",
    thumb: u("photo-1519681393784-d120267933ba", 640),
    full: u("photo-1519681393784-d120267933ba"),
  },
  {
    id: "dark-2",
    title: "Silent Ridge",
    category: "dark",
    thumb: u("photo-1477346611705-65d1883cee1e", 640),
    full: u("photo-1477346611705-65d1883cee1e"),
  },
  {
    id: "dark-3",
    title: "Red Dusk",
    category: "dark",
    thumb: u("photo-1500530855697-b586d89ba3ee", 640),
    full: u("photo-1500530855697-b586d89ba3ee"),
  },
  {
    id: "car-1",
    title: "Night Drive",
    category: "cars",
    thumb: u("photo-1492144534655-ae79c964c9d7", 640),
    full: u("photo-1492144534655-ae79c964c9d7"),
  },
  {
    id: "car-2",
    title: "Garage Red",
    category: "cars",
    thumb: u("photo-1503376780353-7e6692767b70", 640),
    full: u("photo-1503376780353-7e6692767b70"),
  },
  {
    id: "abs-1",
    title: "Silk Gradient",
    category: "abstract",
    thumb: u("photo-1579546929518-9e396f3cc809", 640),
    full: u("photo-1579546929518-9e396f3cc809"),
  },
  {
    id: "abs-2",
    title: "Ink Bloom",
    category: "abstract",
    thumb: u("photo-1550684848-fac1c5b4e853", 640),
    full: u("photo-1550684848-fac1c5b4e853"),
  },
  {
    id: "min-1",
    title: "Soft Field",
    category: "minimal",
    thumb: u("photo-1557683316-973673baf926", 640),
    full: u("photo-1557683316-973673baf926"),
  },
  {
    id: "min-2",
    title: "Quiet Paper",
    category: "minimal",
    thumb: u("photo-1550684848-86a5c4887404", 640),
    full: u("photo-1550684848-86a5c4887404"),
  },
  {
    id: "tech-1",
    title: "Server Glow",
    category: "tech",
    thumb: u("photo-1518770660439-4636190af475", 640),
    full: u("photo-1518770660439-4636190af475"),
  },
  {
    id: "tech-2",
    title: "Circuit Rain",
    category: "tech",
    thumb: u("photo-1550751827-4bd374c3f58b", 640),
    full: u("photo-1550751827-4bd374c3f58b"),
  },
  {
    id: "fan-1",
    title: "Ember Valley",
    category: "fantasy",
    thumb: u("photo-1518709268805-4e9042af9f23", 640),
    full: u("photo-1518709268805-4e9042af9f23"),
  },
  {
    id: "fan-2",
    title: "Aurora Gate",
    category: "fantasy",
    thumb: u("photo-1419242902214-272b3f66ee7a", 640),
    full: u("photo-1419242902214-272b3f66ee7a"),
  },
];
