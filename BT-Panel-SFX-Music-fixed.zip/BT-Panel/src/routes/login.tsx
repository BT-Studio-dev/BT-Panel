import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { AuthShell } from "@/components/panel/auth-shell";
import { resolveLoginEmail } from "@/lib/panel/server";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (!isPending && user) return <Navigate to="/" />;

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const { email } = await resolveLoginEmail({ data: { identifier } });
      const result = await authClient.signIn.email({ email, password, callbackURL: "/" });
      if (result.error) throw new Error(result.error.message || "Invalid username or password.");
      window.location.assign("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid username or password.");
      setBusy(false);
    }
  }

  return (
    <AuthShell
      title="Sign in to continue"
      footer={
        <Link to="/register" className="underline decoration-white/30 underline-offset-4 hover:decoration-white">
          Create account
        </Link>
      }
    >
      <form onSubmit={onSubmit} className="text-left">
        <label className="mt-1 mb-1.5 block text-[11px] font-bold tracking-wide text-steel" htmlFor="user">
          Username or Email
        </label>
        <input
          id="user"
          className="panel-input"
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          placeholder="admin"
          autoComplete="username"
          required
          autoFocus
        />
        <label className="mt-3.5 mb-1.5 block text-[11px] font-bold tracking-wide text-steel" htmlFor="pass">
          Password
        </label>
        <div className="relative">
          <input
            id="pass"
            className="panel-input pr-14"
            type={show ? "text" : "password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="admin"
            autoComplete="current-password"
            required
          />
          <button
            type="button"
            className="absolute top-1/2 right-3 -translate-y-1/2 text-[11px] font-bold text-steel"
            onClick={() => setShow((v) => !v)}
          >
            {show ? "Hide" : "Show"}
          </button>
        </div>
        {error ? <p className="mt-3 text-[13px] font-semibold text-danger">{error}</p> : null}
        <button type="submit" className="btn-accent mt-5 w-full" disabled={busy}>
          {busy ? "Signing in…" : "Login"}
        </button>
      </form>

      {authEnabled && GROK_PROVIDERS.length > 0 ? (
        <div className="mt-5">
          <div className="mb-3 flex items-center gap-3 text-[11px] font-bold tracking-wide text-steel uppercase">
            <span className="h-px flex-1 bg-white/10" />
            or
            <span className="h-px flex-1 bg-white/10" />
          </div>
          <div className="grid gap-2">
            {GROK_PROVIDERS.map((provider) => (
              <button
                key={provider.providerId}
                type="button"
                className="btn-ghost w-full"
                onClick={() => void signIn(provider.providerId, { callbackURL: "/" })}
              >
                Continue with {provider.label}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </AuthShell>
  );
}
